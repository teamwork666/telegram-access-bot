# Telegram Access Bot

Бот для продажи ссылок на доступ в Telegram-каналы с оплатой через ЮMoney.

## 🚀 Быстрый старт

### 1. Клонировать репозиторий
```bash
git clone https://github.com/teamwork666/telegram-access-bot.git
cd telegram-access-bot