const mainKeyboard = {
    reply_markup: {
        keyboard: [
            ['📥 Купить доступ'],
            ['👤 Личный кабинет', '💰 Пополнить баланс'],
            ['Тестовое пополнение'] // удалить позже
        ],
        resize_keyboard: true
    }
};

module.exports = { mainKeyboard };